import pandas as pd
from order import order
import pickle
import numpy
import matplotlib.pyplot as plt
import folium
import webbrowser
from collections import Counter
import csv
import pip
import map
import json




order_dictionary = pd.read_pickle('order_dictionary.pkl')
countries = list(order_dictionary['Order Country'].keys())
country_dictionary = order_dictionary['Order Country']

with open('countries.json', 'r') as f:
    d = json.load(f)
profits = []

for i in countries: #Creates profit list in the same order as countries
    country = country_dictionary[i]
    profits.append(country['Order Profit'].sum()/country.shape[0])


converted_countries = map.convert_countries(countries) #Translates the countries from Spanish to English

bins = map.findBins(profits) #returns list of markings on the 1/8, 2/8, 3/8,... quartiles of data

#createMap takes 5 inputs:
#countries_list: list of countries in English (Use conver_countries to get countries in English)
#countris_data: data graphed as list. Make sure it is in the same order as countries_list (and length)
#data_name: Name of data being graphed
#data_bins: List of markings on the scale. (Optional)
#marker_on: Turns the Puerto Rico marker on or off
map.createMap(converted_countries,profits,'Average Profit Per Country',bins)
