import pandas as pd
from order import order
import pickle
import numpy
import matplotlib.pyplot as plt
import folium
import webbrowser
from collections import Counter
import csv
import pip
import json



with open('countries.json', 'r') as f:
    d = json.load(f)

def createMap(countries_list, countries_data, data_name, data_bins = None, marker_on = True):
    assert len(countries_list) == len(countries_data), 'Number of Countries and Data Points Must be Equal'
    df = pd.DataFrame([countries_list,countries_data]).transpose().dropna()
    my_map = folium.Map()
    if data_bins == None:
        folium.Choropleth(geo_data = d, name = 'choropleth',data = df, columns = [0,1],key_on = 'feature.properties.geounit', fill_color = 'YlGn', fill_opacity = 1,line_opacity = 0.2,legend_name = data_name).add_to(my_map)
    else:
        folium.Choropleth(geo_data = d, name = 'choropleth',data = df, columns = [0,1],key_on = 'feature.properties.geounit', fill_color = 'YlGn', fill_opacity = 1,line_opacity = 0.2,legend_name = data_name, bins = data_bins).add_to(my_map)
    if marker_on:
        folium.Marker([18.25145,-66.0371],popup = 'BigSupplyCo Departments', icon = folium.Icon(color = 'green')).add_to(my_map)
    my_map.save('Newmap.html')
    webbrowser.open('Newmap.html')
def convert_countries(countries_list):
    countries_conversion = pd.read_pickle('countries_conversion.pkl')
    l = []
    for i in countries_list:
        l.append(countries_conversion[i])
    return l
def findBins(data):
    l = [min(data)]
    l2 = list(numpy.quantile(data,[i/8 for i in range(1,8)]))
    l+=l2
    l.append(max(data))
    return l
